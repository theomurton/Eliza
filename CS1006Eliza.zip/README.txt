When running the program, obviously compile it and then run it with the script name as a command line argument.
For instance:
javac Chatbot.java
java Chatbot psychotherapist.txt

When talking with Eliza, simply enter text through standard input.